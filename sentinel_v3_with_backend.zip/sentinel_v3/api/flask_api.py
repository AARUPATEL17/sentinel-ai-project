"""
api/flask_api.py  (v3 FULL BACKEND)
30 REST endpoints across 8 service modules.
Run: python api/flask_api.py
"""
import sys, os, json
from datetime import datetime
from functools import wraps

# ── Fix Python path so imports work from any working directory ─────────────────
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT_DIR)

try:
    from flask import Flask, request, jsonify, Response
    FLASK_OK = True
except ImportError:
    FLASK_OK = False

try:
    from flask_cors import CORS; CORS_OK = True
except ImportError:
    CORS_OK = False

from api.services.ai_detection_service  import audio_service, motion_service, object_service, anomaly_service
from api.services.notification_service import notification_service
from api.services.auth_service         import auth_service
from api.services.location_service     import location_service
from api.services.report_service       import report_service, REPORTLAB_OK
from api.services.chatbot_service      import chatbot_service

from database.db import (
    get_alerts, insert_alert, resolve_alert, get_alert_stats,
    get_alerts_by_type, get_alerts_by_sector, get_all_users, add_user,
    toggle_user, get_notification_logs,
)
import backend as B
ANTHROPIC_KEY = os.getenv("ANTHROPIC_API_KEY","")
OPENAI_KEY    = os.getenv("OPENAI_API_KEY","")


def create_app():
    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.getenv("FLASK_SECRET","sentinel-dev-secret")
    if CORS_OK: CORS(app, origins="*")

    def token_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            hdr = request.headers.get("Authorization","")
            tok = hdr.split(" ",1)[1] if " " in hdr else ""
            p   = auth_service.verify_token(tok)
            if not p: return jsonify({"error":"Unauthorized"}), 401
            request.current_user = p
            return f(*args, **kwargs)
        return decorated

    def admin_required(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            hdr = request.headers.get("Authorization","")
            tok = hdr.split(" ",1)[1] if " " in hdr else ""
            p   = auth_service.verify_token(tok)
            if not p or p.get("role") != "admin":
                return jsonify({"error":"Admin required"}), 403
            request.current_user = p
            return f(*args, **kwargs)
        return decorated

    # ── AUTH ──────────────────────────────────────────────────────────────────
    @app.route("/api/auth/login",       methods=["POST"])
    def login():
        d = request.json or {}
        r = auth_service.login(d.get("username",""), d.get("password",""))
        return jsonify(r), (200 if r["success"] else 401)

    @app.route("/api/auth/logout",      methods=["POST"])
    def logout():
        tok = request.headers.get("Authorization","").split(" ",1)[-1]
        return jsonify(auth_service.logout(tok))

    @app.route("/api/auth/me",          methods=["GET"])
    @token_required
    def me():
        return jsonify({"user": request.current_user,
                        "permissions": auth_service.get_permissions(request.current_user.get("role","officer"))})

    # ── ALERTS ────────────────────────────────────────────────────────────────
    @app.route("/api/alerts",           methods=["GET"])
    def list_alerts():
        level    = request.args.get("level")
        limit    = int(request.args.get("limit",50))
        resolved = request.args.get("resolved")
        if resolved is not None: resolved = int(resolved)
        alerts = get_alerts(limit=limit, level=level, resolved=resolved)
        return jsonify({"alerts": alerts, "count": len(alerts)})

    @app.route("/api/alerts",           methods=["POST"])
    def create_alert():
        d   = request.json or {}
        aid = insert_alert(d.get("level","MEDIUM"), d.get("type","sensor"),
                           d.get("sector","Unknown"), d.get("message",""),
                           d.get("lat"), d.get("lon"), d.get("score",0.5), d.get("source","api"))
        if d.get("auto_dispatch") and d.get("level") in ("CRITICAL","HIGH"):
            notification_service.dispatch_alert({"id":aid,**d,"created_at":datetime.now().isoformat()})
        return jsonify({"success":True,"alert_id":aid}), 201

    @app.route("/api/alerts/<int:aid>/resolve", methods=["PUT"])
    def resolve(aid):
        resolve_alert(aid, (request.json or {}).get("resolved_by","api"))
        return jsonify({"success":True,"alert_id":aid})

    @app.route("/api/alerts/<int:aid>", methods=["DELETE"])
    @admin_required
    def delete_alert(aid):
        from database.db import get_conn
        conn = get_conn(); conn.execute("DELETE FROM alerts WHERE id=?",(aid,)); conn.commit(); conn.close()
        return jsonify({"success":True,"deleted_id":aid})

    @app.route("/api/alerts/stats",     methods=["GET"])
    def alert_stats():
        return jsonify(get_alert_stats())

    @app.route("/api/alerts/by-type",   methods=["GET"])
    def alerts_by_type():
        return jsonify({"data": get_alerts_by_type()})

    @app.route("/api/alerts/by-sector", methods=["GET"])
    def alerts_by_sector():
        return jsonify({"data": get_alerts_by_sector()})

    # ── AI DETECTION ──────────────────────────────────────────────────────────
    @app.route("/api/ai/analyze-audio", methods=["POST"])
    def analyze_audio():
        d = request.json or {}
        audio_service.sensitivity = float(d.get("sensitivity",0.65))
        signal = d.get("signal") or audio_service.simulate_signal(d.get("event_type","ambient"),float(d.get("duration",1.0)))
        result = audio_service.analyze(signal)
        if result["gunshot"]["detected"]:
            insert_alert("CRITICAL","gunshot",d.get("sector","Unknown"),
                         f"Gunshot detected — conf {result['gunshot']['confidence']}",
                         score=result["gunshot"]["confidence"], source="audio_ai")
        elif result["scream"]["detected"]:
            insert_alert("HIGH","scream",d.get("sector","Unknown"),
                         f"Scream detected — conf {result['scream']['confidence']}",
                         score=result["scream"]["confidence"], source="audio_ai")
        return jsonify(result)

    @app.route("/api/ai/analyze-motion",  methods=["POST"])
    def analyze_motion():
        d = request.json or {}
        motion_service.sensitivity = float(d.get("sensitivity",0.65))
        result = motion_service.analyze_frame()
        if result["suspicious"]:
            insert_alert("HIGH","motion",d.get("sector","Unknown"),
                         f"Suspicious movement — pattern: {result['pattern']}",
                         score=result["confidence"], source="motion_ai")
        return jsonify(result)

    @app.route("/api/ai/detect-objects",  methods=["POST"])
    def detect_objects():
        d      = request.json or {}
        result = object_service.detect()
        lvl    = result["alert_level"]
        if lvl in ("CRITICAL","HIGH","MEDIUM"):
            typ = "weapon" if lvl=="CRITICAL" else "unknown_person"
            insert_alert(lvl,typ,d.get("sector","Unknown"),
                         f"{typ.replace('_',' ').title()} detected — {result['object_count']} objects",
                         score=result["threat_score"], source="cctv_ai")
        return jsonify(result)

    @app.route("/api/ai/anomaly-scan",    methods=["GET"])
    def anomaly_scan():
        n = int(request.args.get("n",200))
        return jsonify(anomaly_service.analyze_batch(B.generate_sensor_readings(n)))

    @app.route("/api/ai/threat-summary",  methods=["GET"])
    def threat_summary():
        rows, metrics = B.run_anomaly_detection(B.generate_sensor_readings(100))
        zones  = B.predict_risk_zones()
        alerts = get_alerts(limit=10, resolved=0)
        threats= [a for a in alerts if a["level"] in ("CRITICAL","HIGH")]
        return jsonify({
            "timestamp":       datetime.now().isoformat(),
            "anomaly_rate":    round(sum(1 for r in rows if r["predicted_anomaly"])/len(rows),4),
            "model_auc":       metrics["auc_roc"],
            "model_f1":        metrics["f1"],
            "top_risk_sector": zones[0]["sector"] if zones else "N/A",
            "top_risk_score":  zones[0]["risk_score"] if zones else 0,
            "active_threats":  len(threats),
            "critical_zones":  sum(1 for z in zones if z["risk_level"]=="CRITICAL"),
            "threat_summary":  [{"level":a["level"],"message":a["message"],"sector":a["sector"]} for a in threats[:5]],
            "risk_zones":      zones[:6],
        })

    # ── LOCATIONS ─────────────────────────────────────────────────────────────
    @app.route("/api/locations",                     methods=["GET"])
    def get_locs():
        return jsonify({"locations": location_service.get_all_positions()})

    @app.route("/api/locations",                     methods=["POST"])
    def post_loc():
        d = request.json or {}
        result = location_service.update_position(
            d.get("unit_id","UNIT-X"), d.get("unit_type","officer"),
            float(d.get("lat",29.5)), float(d.get("lon",74.5)),
            float(d.get("speed",0)), float(d.get("heading",0)))
        for v in result.get("violations",[]):
            insert_alert(v["level"],"geofence_violation",v.get("zone_id",""),
                         f"Unit {v['unit_id']} in restricted zone: {v['zone_name']}",
                         lat=v["lat"],lon=v["lon"],score=0.95,source="gps")
        return jsonify(result), 201

    @app.route("/api/locations/<unit_id>/history",   methods=["GET"])
    def unit_history(unit_id):
        return jsonify(location_service.get_unit_history(unit_id, int(request.args.get("limit",50))))

    @app.route("/api/locations/simulate-patrol",     methods=["POST"])
    def simulate_patrol():
        results = location_service.simulate_all_patrols()
        return jsonify({"updated": len(results), "positions": results})

    @app.route("/api/locations/nearest",             methods=["GET"])
    def nearest():
        return jsonify({"nearest": location_service.nearest_units(
            float(request.args.get("lat",29.5)), float(request.args.get("lon",74.5)),
            int(request.args.get("n",3)))})

    # ── NOTIFICATIONS ─────────────────────────────────────────────────────────
    @app.route("/api/notify/sms",      methods=["POST"])
    def notify_sms():
        d = request.json or {}
        return jsonify(notification_service.send_sms(d.get("to",""),d.get("message",""),d.get("alert_id",0)))

    @app.route("/api/notify/email",    methods=["POST"])
    def notify_email():
        d = request.json or {}
        return jsonify(notification_service.send_email(d.get("to",""),d.get("subject","SENTINEL"),d.get("body",""),d.get("alert_id",0)))

    @app.route("/api/notify/dispatch", methods=["POST"])
    def dispatch():
        d = request.json or {}
        return jsonify(notification_service.dispatch_alert(d.get("alert",{}),d.get("sms_to"),d.get("email_to")))

    @app.route("/api/notify/logs",     methods=["GET"])
    def notify_logs():
        return jsonify({"logs": get_notification_logs(int(request.args.get("limit",30)))})

    # ── CHATBOT ───────────────────────────────────────────────────────────────
    @app.route("/api/chat",                    methods=["POST"])
    def chat():
        d = request.json or {}
        if not d.get("message"): return jsonify({"error":"message required"}),400
        return jsonify(chatbot_service.respond(d.get("session_id","default"),d.get("message"),d.get("provider","rule"),d.get("api_key")))

    @app.route("/api/chat/<sid>/history",      methods=["GET"])
    def chat_history(sid):
        return jsonify({"history": chatbot_service.get_history(sid, int(request.args.get("limit",50)))})

    @app.route("/api/chat/<sid>",              methods=["DELETE"])
    def clear_chat(sid):
        return jsonify(chatbot_service.clear_history(sid))

    # ── REPORTS ───────────────────────────────────────────────────────────────
    @app.route("/api/reports/summary",         methods=["GET"])
    def rpt_summary():  return jsonify(report_service.get_summary())

    @app.route("/api/reports/trend",           methods=["GET"])
    def rpt_trend():    return jsonify(report_service.get_trend(int(request.args.get("days",30))))

    @app.route("/api/reports/export/csv",      methods=["GET"])
    def rpt_csv():
        return Response(report_service.export_alerts_csv(), mimetype="text/csv",
                        headers={"Content-Disposition":"attachment; filename=sentinel_alerts.csv"})

    @app.route("/api/reports/export/json",     methods=["GET"])
    def rpt_json():
        return Response(report_service.export_json_report(), mimetype="application/json",
                        headers={"Content-Disposition":"attachment; filename=sentinel_report.json"})

    @app.route("/api/reports/export/pdf",      methods=["GET"])
    def rpt_pdf():
        pdf = report_service.export_pdf_report()
        if pdf is None: return jsonify({"error":"pip install reportlab"}), 501
        return Response(pdf, mimetype="application/pdf",
                        headers={"Content-Disposition":"attachment; filename=sentinel_report.pdf"})

    @app.route("/api/reports/performance",     methods=["GET"])
    def rpt_perf():   return jsonify(report_service.get_performance_metrics())

    # ── USERS ─────────────────────────────────────────────────────────────────
    @app.route("/api/users",           methods=["GET"])
    def list_users():
        users = get_all_users()
        for u in users: u.pop("password_hash",None)
        return jsonify({"users": users, "count": len(users)})

    @app.route("/api/users",           methods=["POST"])
    def create_user():
        d = request.json or {}
        ok, msg = add_user(d.get("username"),d.get("password"),d.get("role","officer"),d.get("name",""),d.get("badge",""),d.get("sector",""))
        return jsonify({"success":ok,"message":msg}), (201 if ok else 400)

    @app.route("/api/users/<int:uid>/toggle", methods=["PUT"])
    @admin_required
    def toggle_u(uid):
        toggle_user(uid,int((request.json or {}).get("active",1)))
        return jsonify({"success":True})

    @app.route("/api/users/<int:uid>", methods=["GET"])
    def get_user(uid):
        u = next((u for u in get_all_users() if u["id"]==uid), None)
        if not u: return jsonify({"error":"Not found"}),404
        u.pop("password_hash",None); return jsonify({"user":u})

    # ── SYSTEM ────────────────────────────────────────────────────────────────
    @app.route("/api/health", methods=["GET"])
    def health():
        return jsonify({
            "status":"ok","service":"SENTINEL API","version":"3.0",
            "timestamp": datetime.now().isoformat(),
            "features":{
                "audio_detection":True,"motion_detection":True,
                "object_detection":True,"anomaly_detection":True,
                "sms_alerts":bool(notification_service.twilio_sid),
                "email_alerts":bool(notification_service.smtp_user),
                "gps_tracking":True,
                "ai_chatbot":bool(ANTHROPIC_KEY or OPENAI_KEY),
                "pdf_reports":REPORTLAB_OK,
            }
        })

    @app.route("/api/version", methods=["GET"])
    def version():
        return jsonify({"name":"SENTINEL Border Defence AI","version":"3.0.0",
                        "endpoints":30,"services":["auth","alerts","ai_detection",
                        "locations","notifications","chatbot","reports","users"]})

    @app.route("/api", methods=["GET"])
    def api_index():
        return jsonify({"message":"SENTINEL API v3.0","health":"/api/health",
                        "endpoints":"/api/alerts /api/ai /api/chat /api/reports"})

    return app


if __name__ == "__main__":
    if not FLASK_OK:
        print("Run: pip install flask flask-cors"); exit(1)
    app  = create_app()
    host = os.getenv("FLASK_HOST","0.0.0.0")
    port = int(os.getenv("FLASK_PORT","5050"))
    print(f"\n{'='*52}\n  SENTINEL API v3.0 — 30 endpoints\n  http://127.0.0.1:{port}/api/health\n{'='*52}\n")
    app.run(host=host, port=port, debug=True, use_reloader=False)
